<!DOCTYPE html>
<html>
<head>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <p>Auto reload page and clear cache</p>
    <!--    <meta http-equiv="refresh" content="60">-->
    <script>
        $(document).ready(function () {
            setInterval(function () {
                cache_clear()
            }, 60000);
        });

        function cache_clear() {
            window.location.reload(true);
            // window.location.reload(); use this if you do not remove cache
        }

    </script>
</head>


<body>

<h1>My First Google Map</h1>

<div id="googleMap" style="width:100%;height:600px;"></div>

<script>
    function myMap() {
        var myLatlng1 = new google.maps.LatLng(37.2567188, 50.5596113);
        var mapProp = {
            center: myLatlng1,
            zoom: 12,
            mapTypeId: google.maps.MapTypeId.ROADMAP

        };
        var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);

        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title: "Hello World!"
        });

        <?php
        $cn = mysqli_connect("127.0.0.1", "root", "", "GpsLocationTest");
        $sql = "SELECT * FROM Locations ORDER BY LocationId DESC";
        $result = mysqli_query($cn, $sql);

        $devices = array();
        while ($row = mysqli_fetch_assoc($result)) {

        $deviceId = $row['DeviceId'];
        $toadd = true;
        foreach ($devices as $device) {
            if ($device == $deviceId) {
                $toadd = false;
                break;
            }
        }

        if ($toadd == false)
            break;

        $devices[] = $deviceId;

        ?>
        var myLatlng = new google.maps.LatLng(<?php echo $row["Latitude"]; ?>, <?php echo $row["Longitude"]; ?>);
        var marker = new google.maps.Marker({
            position: myLatlng,
            map: map,
            title: "hello",
            icon: 'icon.png'
        });
        <?php
        }
        ?>
    }
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDbb_EU0UuOoNsmzzkihQPBuwQu7YCBZug&callback=myMap"></script>


<!--
To use this code on your website, get a free API key from Google.
Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
-->

</body>
</html>
